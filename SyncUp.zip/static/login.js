document.getElementById('loginForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  const user = JSON.parse(localStorage.getItem(username));
  if (user && user.password === password) {
    alert('Login successful!');
    window.location.href = user.role === 'applicant' ? 'applicant.html' : 'recruiter.html';
  } else {
    alert('Invalid credentials!');
  }
});