document.getElementById('signupForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const role = document.getElementById('role').value;
  const email = document.getElementById('email').value;
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  localStorage.setItem(username, JSON.stringify({ role, email, username, password }));
  alert('Signup successful! Please login.');
  window.location.href = 'login.html';
});