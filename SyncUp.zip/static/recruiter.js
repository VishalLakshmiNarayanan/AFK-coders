document.getElementById('jobForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const company = document.getElementById('companyName').value;
  const description = document.getElementById('jobDescription').value;
  const timeline = document.getElementById('timeline').value;

  const jobs = JSON.parse(localStorage.getItem('jobs') || '[]');
  jobs.push({ company, description, timeline });
  localStorage.setItem('jobs', JSON.stringify(jobs));
  alert('Job posted successfully!');
});