
localStorage.removeItem('jobs');
localStorage.removeItem('parsedSkills');

localStorage.setItem('parsedSkills', JSON.stringify(['Python', 'SQL', 'Java', 'HTML', 'CSS', 'ReactJS', 'NodeJS', 'TensorFlow', 'Pytorch', 'Scikit-Learn', 'Pandas', 'NumPy', 'Deep Learning', 'Natural Language Processing', 'Malware Analysis', 'Flask']));
document.getElementById('resumeForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const parsedSkills = ['JavaScript', 'Python', 'React'];
  localStorage.setItem('parsedSkills', JSON.stringify(parsedSkills));
  document.getElementById('parsedSkills').innerText = 'Parsed skills: ' + parsedSkills.join(', ');
  renderJobs(parsedSkills);
});

function renderJobs(parsedSkills) {
  const jobs = JSON.parse(localStorage.getItem('jobs') || '[]');
  const jobList = document.getElementById('jobListings');
  jobList.innerHTML = '';
  jobs.forEach(job => {
    const jobSkills = extractSkills(job.description);
    const missingSkills = jobSkills.filter(skill => !parsedSkills.includes(skill));
    const li = document.createElement('li');
    li.innerHTML = `<strong>${job.company}</strong> - ${job.description} (Deadline: ${job.timeline})<br/>
                    <span style='color: green;'>Matched Skills: ${jobSkills.filter(skill => parsedSkills.includes(skill)).join(', ')}</span><br/>
                    <span style='color: red;'>Missing Skills: ${missingSkills.join(', ')}</span><br/>
                    <button onclick="suggestCourses('${missingSkills.join(',')}')">Suggest Courses</button>
                    <div id="courses_${job.company.replace(/\s/g, '_')}"></div>`;
    jobList.appendChild(li);
  });
}

function extractSkills(description) {
  const skills = ['JavaScript', 'Python', 'React', 'Node.js', 'SQL', 'HTML', 'CSS'];
  return skills.filter(skill => description.includes(skill));
}

function suggestCourses(missing) {
  const skills = missing.split(',');
  fetch('http://localhost:5000/recommend', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ skills: skills })
  })
  .then(response => response.json())
  .then(data => {
    const coursesHtml = data.courses.map(course => `<li>${course}</li>`).join('');
    const courseDiv = document.querySelector(`[id^='courses_']`);
    courseDiv.innerHTML = `<ul>${coursesHtml}</ul>`;
  });
}

document.addEventListener('DOMContentLoaded', () => {
  const parsedSkills = JSON.parse(localStorage.getItem('parsedSkills') || '[]');
  renderJobs(parsedSkills);
});