
from flask import Flask, render_template, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/signup')
def signup():
    return render_template('signup.html')

@app.route('/applicant')
def applicant():
    return render_template('applicant.html')

@app.route('/recruiter')
def recruiter():
    return render_template('recruiter.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

# Course recommendation endpoint
@app.route('/recommend', methods=['POST'])
def recommend():
    data = request.get_json()
    skills = data.get('skills', [])
    course_db = {
        "Python": ["Python for Everybody", "Automate the Boring Stuff", "Python 3 Bootcamp", "Data Science with Python", "Intro to Python"],
        "ReactJS": ["Modern React", "React Complete Guide", "React for Beginners", "Frontend with React", "React Hooks"],
        "NodeJS": ["Node.js Crash Course", "Complete Node Guide", "Express Basics", "API Development", "Node Mastery"],
        "SQL": ["SQL for Data Analysis", "Master SQL", "Intro to DB", "Advanced Queries", "SQL Bootcamp"],
        "TensorFlow": ["Intro to TensorFlow", "TF Developer", "TF Image Classifier", "TF for AI", "TF Bootcamp"],
        "Pytorch": ["Intro to PyTorch", "Deep Learning PyTorch", "AI with PyTorch", "PyTorch Basics", "Advanced PyTorch"],
        "Flask": ["Flask for Beginners", "Flask Web Dev", "APIs with Flask", "Flask Apps", "Flask Mega-Tutorial"],
        "Java": ["Java Masterclass", "Data Structures Java", "Java for Beginners", "Java 17", "Advanced Java"]
    }
    recommended = []
    for skill in skills:
        if skill in course_db:
            recommended.extend(course_db[skill][:2])
    return jsonify({"courses": recommended[:5]})

if __name__ == '__main__':
    app.run(debug=True)
